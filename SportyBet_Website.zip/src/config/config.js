export const backend_URL = "https://api.admingh.online/api";
export const backend_URL1 = "https://api.admingh.online";
// export const backend_URL = "http://localhost:5002/api";
// export const backend_URL1 = "http://localhost:5002";

